//
//  registrationViewController.h
//  Vkontakte Messenger
//
//  Created by Vladislav Zagorodnyuk on 3/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface registrationViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *phoneNumberTextField;
@property (weak, nonatomic) IBOutlet UITextField *firstNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *lastNameTextField;
@property (weak, nonatomic) IBOutlet UISegmentedControl *genderChecker;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UIWebView *registrationWebView;
- (IBAction)dismissModalViewController:(id)sender;
- (IBAction)sendRegistrationInformation:(id)sender;

@end
