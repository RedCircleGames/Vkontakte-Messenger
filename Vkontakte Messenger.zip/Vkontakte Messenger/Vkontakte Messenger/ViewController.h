//
//  ViewController.h
//  Vkontakte Messenger
//
//  Created by Vladislav Zagorodnyuk on 3/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *loginTextField;
@property (weak, nonatomic) IBOutlet UIWebView *mainWebView;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
- (IBAction)loginButton:(id)sender;
- (IBAction)registrationButton:(id)sender;
- (IBAction)changeLanguageButton:(id)sender;

@end
