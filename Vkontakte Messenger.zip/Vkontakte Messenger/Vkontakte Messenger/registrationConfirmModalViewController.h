//
//  registrationConfirmModalViewController.h
//  Vkontakte Messenger
//
//  Created by Vladislav Zagorodnyuk on 3/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface registrationConfirmModalViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *confirmationCodeTextFIeld;
@property (weak, nonatomic) IBOutlet UIWebView *registrationConfirmWebView;
@property (weak, nonatomic) IBOutlet UITextField *phoneNumberTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;

- (IBAction)sendConfirmationAction:(id)sender;
- (IBAction)cancelAction:(id)sender;

@end
