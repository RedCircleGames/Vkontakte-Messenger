//
//  test.h
//  Vkontakte Messenger
//
//  Created by Vladislav Zagorodnyuk on 3/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface test : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *testWebView;
- (IBAction)testAction:(id)sender;

@end
