//
//  ViewController.m
//  Vkontakte Messenger
//
//  Created by Vladislav Zagorodnyuk on 3/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import <YAJLiOS/YAJL.h>

@implementation ViewController
@synthesize loginTextField;
@synthesize mainWebView;
@synthesize passwordTextField;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{

    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setMainWebView:nil];
    [self setLoginTextField:nil];
    [self setPasswordTextField:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)loginButton:(id)sender 
{
    NSString *loginAutorization = [NSString stringWithFormat:@"https://oauth.vk.com/token?grant_type=password&client_id=2848296&client_secret=j5ybMsVr77inRHDIf5qh&username=%@&password=%@&scope=offline,messages,friends",loginTextField.text,passwordTextField.text];//get better permittion for using other methods
    
    //Create a URL object.
    NSURL *url = [NSURL URLWithString:loginAutorization];
    
    //URL Requst Object
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    
    NSData *tempContainer = [NSURLConnection sendSynchronousRequest:requestObj  
                                                  returningResponse:nil
                                                              error:nil];
    
    NSString *strData = [[NSString alloc]initWithData:tempContainer encoding:NSUTF8StringEncoding];
    NSArray *JSONArray = [tempContainer yajl_JSON];
   
    NSLog(@"%@",strData);
    //Load the request in the UIWebView.
    //NSArray *arrayFromData = [tempContainer yajl_JSON];
    [mainWebView loadRequest:requestObj];
}

- (IBAction)registrationButton:(id)sender {
}

- (IBAction)changeLanguageButton:(id)sender 
{
    NSString *loginAutorization = [NSString stringWithFormat:@"https://api.vk.com/method/messages.get?access_token=4bef97c44219e6e64219e6e62b423290ce442194219e6e6a1e1d0a2f816b96f&out=1"];//permition for a.t.
    
    //Create a URL object.
    NSURL *url = [NSURL URLWithString:loginAutorization];
    
    //URL Requst Object
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    
    //Load the request in the UIWebView.
    [mainWebView loadRequest:requestObj];
}

@end
